<?php

class Coinbase_ApiException extends Coinbase_Exception
{
}
